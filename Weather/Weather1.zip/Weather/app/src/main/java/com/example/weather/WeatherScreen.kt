package com.example.weather

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun WeatherScreen(viewModel: WeatherViewModel = viewModel()) {
    var date by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    val weatherData = viewModel.weatherData.collectAsState().value
    val isLoading = viewModel.isLoading.collectAsState().value
    val errorMessage = viewModel.errorMessage.collectAsState().value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        OutlinedTextField(
            value = date,
            onValueChange = { date = it },
            label = { Text("Enter Date (YYYY-MM-DD)") }
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = location,
            onValueChange = { location = it },
            label = { Text("Enter Location") }
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = { viewModel.loadWeatherData(location, date) },
            enabled = !isLoading
        ) {
            Text("Get Weather")
        }

        if (isLoading) {
            CircularProgressIndicator()
        } else {
            weatherData?.let { data ->
                Spacer(modifier = Modifier.height(16.dp))
                Text("Max Temp: ${data.tempmax}°C")
                Text("Min Temp: ${data.tempmin}°C")
                Text("Description: ${data.description}")
            }

            if (!errorMessage.isNullOrEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Text("Error: $errorMessage", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
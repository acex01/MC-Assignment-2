package com.example.weather

data class WeatherResponse(
    val days: List<WeatherDay>
    // Add other fields as necessary
)

// WeatherDay.kt
data class WeatherDay(
    val datetime: String,
    val tempmax: Double,
    val tempmin: Double,
    val description: String
    // Add other fields from the day object
)
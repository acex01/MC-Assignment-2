package com.example.weather

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.Response
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.HttpException

class WeatherViewModel : ViewModel() {
    val weatherData = MutableStateFlow<WeatherDay?>(null)
    val isLoading = MutableStateFlow(false)
    val errorMessage = MutableStateFlow<String?>(null)

    private val visualCrossingService: VisualCrossingService by lazy {
        Retrofit.Builder()
            .baseUrl("https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(VisualCrossingService::class.java)
    }

    fun loadWeatherData(location: String, startDate: String) {
        viewModelScope.launch {
            isLoading.value = true
            try {
                val response: Response<WeatherResponse> = visualCrossingService.getHistoricalWeather(
                    location, startDate, "WTU4ET8PLN34TWR4CXAHWGV4Z"
                )
                if (response.isSuccessful && response.body() != null) {
                    weatherData.value = response.body()?.days?.firstOrNull()
                } else {
                    errorMessage.value = "Error: ${response.message()}"
                }
            } catch (e: HttpException) {
                errorMessage.value = "HTTP Error: ${e.code()}"
            } catch (e: Exception) {
                errorMessage.value = "Exception: ${e.localizedMessage}"
            } finally {
                isLoading.value = false
            }
        }
    }
}

